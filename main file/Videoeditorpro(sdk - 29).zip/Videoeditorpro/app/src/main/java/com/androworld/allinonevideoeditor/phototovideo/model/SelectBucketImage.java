package com.androworld.allinonevideoeditor.phototovideo.model;

import java.util.ArrayList;

public class SelectBucketImage {
    public String bucketid;
    public int count;
    public ArrayList<AlbumImages> imgUri;
}

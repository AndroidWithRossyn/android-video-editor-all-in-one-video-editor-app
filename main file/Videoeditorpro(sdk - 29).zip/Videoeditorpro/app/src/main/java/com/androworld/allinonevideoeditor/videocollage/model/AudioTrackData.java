package com.androworld.allinonevideoeditor.videocollage.model;

public class AudioTrackData {
    public boolean isSelected;
    public int mapPosition;

    public AudioTrackData(int i, boolean z) {
        this.mapPosition = i;
        this.isSelected = z;
    }


}

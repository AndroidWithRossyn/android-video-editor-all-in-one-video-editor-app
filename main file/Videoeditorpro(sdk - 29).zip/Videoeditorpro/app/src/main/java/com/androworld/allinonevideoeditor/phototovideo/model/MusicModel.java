package com.androworld.allinonevideoeditor.phototovideo.model;

public class MusicModel {
    public String duration;
    public String name;
    public String path;
    public String size;

    public MusicModel(String str, String str2) {
        this.name = str;
        this.path = str2;
    }
}

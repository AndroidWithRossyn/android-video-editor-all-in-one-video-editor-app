package com.androworld.allinonevideoeditor;

public class Styleable {


    public static final int[] HorizontalListView = {16842976, 16843049, 16843685, R.attr.dividerWidth};
    public static final int[] SingleFingerView = {R.attr.image, R.attr.image_width, R.attr.image_height, R.attr.push_image, R.attr.push_deleteimage, R.attr.push_image_width, R.attr.push_image_height, R.attr.top, R.attr.left, R.attr.centerInParent};
}

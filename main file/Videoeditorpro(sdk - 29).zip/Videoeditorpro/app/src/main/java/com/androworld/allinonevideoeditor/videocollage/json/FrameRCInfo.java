package com.androworld.allinonevideoeditor.videocollage.json;

import com.google.gson.annotations.SerializedName;

public class FrameRCInfo {
    @SerializedName("row")
    public int numRow;
}

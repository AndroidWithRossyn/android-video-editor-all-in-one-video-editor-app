package com.androworld.allinonevideoeditor.videocollage.stickers;

public class HsItem {
    public boolean isAvailable;
    public String path;

    public HsItem(String str, boolean z) {
        this.path = str;
        this.isAvailable = z;
    }
}

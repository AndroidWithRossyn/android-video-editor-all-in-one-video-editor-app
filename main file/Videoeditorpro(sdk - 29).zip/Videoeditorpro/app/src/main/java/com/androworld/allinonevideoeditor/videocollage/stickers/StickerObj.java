package com.androworld.allinonevideoeditor.videocollage.stickers;

public class StickerObj {
    public String StickerPath;
    public int StickerX;
    public int StickerY;

    public StickerObj(String str, int i, int i2) {
        this.StickerPath = str;
        this.StickerX = i;
        this.StickerY = i2;
    }
}

package com.androworld.allinonevideoeditor;

import android.graphics.Typeface;

public class Helper {
    public static String FontStyle = "AVENIRLTSTD-MEDIUM.OTF";
    public static int ModuleId = 0;
    public static String account_string = "https://play.google.com/store/apps/developer?id=andro+world&hl=en";
    public static String app_name = "Video Editor With Music";
    public static String audioname = null;
    public static String audiopath = null;
    public static String audiopath1 = null;
    public static String package_name = "https://play.google.com/store/apps/details?id=com.androworld.allinonevideoeditor";
    public static String share_string = "Hey!Check Out Video Editor With Music app is Professional Video Editing tool for your daily needs with most useful and handy Features to edit your video within minutes.!!!";
    public static Typeface txtface;



}

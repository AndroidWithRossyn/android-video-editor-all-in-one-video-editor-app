package com.androworld.allinonevideoeditor.phototovideo.model;

public class ImageSelect {
    public int cropIndex;
    public int imgId;
    public int imgPos;
    public String imgUri;
    public int indexId;

    public String getImgUri() {
        return this.imgUri;
    }

    public int getImgPos() {
        return this.imgPos;
    }
}

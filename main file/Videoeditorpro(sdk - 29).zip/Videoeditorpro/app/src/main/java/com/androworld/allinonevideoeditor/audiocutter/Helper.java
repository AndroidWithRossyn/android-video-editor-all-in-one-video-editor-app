package com.androworld.allinonevideoeditor.audiocutter;

import android.graphics.Typeface;

public class Helper {
    public static String FontStyle = "AVENIRLTSTD-MEDIUM.OTF";
    public static Typeface txtface;
}

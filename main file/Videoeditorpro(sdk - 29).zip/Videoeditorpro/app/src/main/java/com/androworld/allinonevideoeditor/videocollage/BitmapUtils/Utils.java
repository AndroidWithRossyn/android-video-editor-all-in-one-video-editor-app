package com.androworld.allinonevideoeditor.videocollage.BitmapUtils;

import android.annotation.SuppressLint;

public class Utils {
    public static int color = -16711936;
    public static int height;
    @SuppressLint({"NewApi"})
    public static int width;
}

package com.androworld.allinonevideoeditor.phototovideo.util;

public class HsItem {
    public boolean isAvailable;
    public String path;

    public HsItem(String str, boolean z) {
        this.path = str;
        this.isAvailable = z;
    }
}

package com.androworld.allinonevideoeditor.videocollage.utils;

import com.androworld.allinonevideoeditor.videocollage.model.BorderAttribute;
import com.androworld.allinonevideoeditor.videocollage.model.CollageData;
import com.androworld.allinonevideoeditor.videocollage.stickers.StickerData;

import java.util.ArrayList;

public class Utils {
    public static ArrayList<BorderAttribute> borderParam = new ArrayList<>();
    public static ArrayList<BorderFrameLayout> borderlayout = new ArrayList<>();
    public static ArrayList<StickerData> clgstickerviewsList = new ArrayList<>();
    public static ArrayList<CollageData> collageData = new ArrayList<>();
    public static int position = 0;
    public static int selectedPos = 0;
    public static String selectedText = "";
}

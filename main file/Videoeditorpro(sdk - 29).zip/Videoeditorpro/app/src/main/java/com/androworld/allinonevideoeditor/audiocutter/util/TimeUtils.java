package com.androworld.allinonevideoeditor.audiocutter.util;

public class TimeUtils {

    public class MilliSeconds {
        public static final int ONE_HOUR = 3600000;
        public static final int ONE_MINUTE = 60000;

        public MilliSeconds() {
        }
    }
}

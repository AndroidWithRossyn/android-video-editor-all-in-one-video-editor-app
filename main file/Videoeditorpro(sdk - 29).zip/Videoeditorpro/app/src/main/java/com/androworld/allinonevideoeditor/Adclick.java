package com.androworld.allinonevideoeditor;

public interface Adclick {
    void onclicl();
}

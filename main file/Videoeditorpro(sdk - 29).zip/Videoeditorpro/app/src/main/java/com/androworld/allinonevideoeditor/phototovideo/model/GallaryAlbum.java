package com.androworld.allinonevideoeditor.phototovideo.model;

import android.net.Uri;

public class GallaryAlbum {
    public String bucketId;
    public String bucketName;
    public int count;
    public int imgId;
    public Uri imgUri;
}

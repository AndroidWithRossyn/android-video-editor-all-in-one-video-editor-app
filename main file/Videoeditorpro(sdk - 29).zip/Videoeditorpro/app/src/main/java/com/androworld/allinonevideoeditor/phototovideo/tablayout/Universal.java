package com.androworld.allinonevideoeditor.phototovideo.tablayout;

import androidx.viewpager.widget.ViewPager;

import com.androworld.allinonevideoeditor.phototovideo.tablayout.HomeTab.TabPagerAdapter;

public class Universal {
    public static TabPagerAdapter fadt;
    public static ViewPager vobj;
}
